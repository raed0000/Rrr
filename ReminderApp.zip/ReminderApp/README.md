# Audio Reminder

An Android app (Kotlin + Jetpack Compose) that lets you set daily reminders,
each with its own custom sound — either picked from your phone's storage or
recorded right in the app.

## How to open and build

1. Install **Android Studio** (Koala or newer) if you don't have it.
2. Open Android Studio → **Open** → select this `ReminderApp` folder.
3. Let Gradle sync (it will download dependencies the first time — needs
   internet access).
4. Plug in a phone (with USB debugging on) or start an emulator running
   **Android 8.0 (API 26) or higher**.
5. Click **Run ▶**.

## How it works

- **Add a reminder**: tap the `+` button, give it a title, pick a time, then
  either **Choose file** (pick any audio file from your device) or
  **Record audio** (records straight from the mic and saves it in the app's
  private storage).
- Reminders repeat **every day** at the chosen time.
- When it's time, the app plays the sound and shows a notification with a
  **Stop** button.
- Toggle the switch next to a reminder to enable/disable it without deleting
  it. Tap the trash icon to remove it.
- Reminders still fire after a phone restart (a boot receiver
  re-schedules everything).

## Permissions it asks for

- **Microphone** — only needed if you record audio in-app.
- **Notifications** — to show the "reminder playing" notification (Android 13+).
- **Audio files** — to let you pick a file from storage (Android 13+ uses
  `READ_MEDIA_AUDIO`).
- **Exact alarms** — so reminders fire at the precise minute you set, even in
  Doze mode.

## Build an APK from your phone (no PC needed)

This project includes a ready-made GitHub Actions workflow
(`.github/workflows/build-apk.yml`) that builds the APK in the cloud.

1. Create a free account at [github.com](https://github.com) if you don't
   have one.
2. Create a **new repository** (any name, e.g. `audio-reminder`). Public or
   private both work.
3. Upload this entire `ReminderApp` folder's contents into that repo. On
   your phone, the easiest way is: open the repo in a mobile browser →
   **Add file → Upload files** → select all the files/folders from the
   unzipped project (do this a folder at a time if the uploader complains
   about the count) → commit.
4. Once the upload commits, go to the **Actions** tab of the repo. A
   workflow run called "Build APK" should start automatically (or tap
   **Run workflow** if it didn't).
5. Wait for it to finish (a few minutes — you'll see a green checkmark).
6. Open that finished run, scroll to **Artifacts**, and download
   `audio-reminder-debug-apk` — that's a zip containing your `app-debug.apk`.
7. Unzip it on your phone and tap the APK to install (allow "install from
   unknown sources" if prompted).

Any time you change the code and push again, it'll automatically rebuild.

## Notes / things you may want to adjust

- Currently every reminder repeats **daily**. If you want specific weekdays
  (e.g. only Mon/Wed/Fri) or one-time reminders, that logic lives in
  `AlarmScheduler.kt` and `Reminder.kt` — it's a small extension from here.
- On some devices (Samsung, Xiaomi, etc.) you may need to manually exempt the
  app from battery optimization for alarms to stay reliable long-term.
- This project was written and organized by hand for you to build in Android
  Studio — it hasn't been compiled/run in this environment, so if Gradle
  flags a small version mismatch, bump the relevant dependency version.
