# Audio Reminder

An Android app (Kotlin + Jetpack Compose) that lets you set daily reminders,
each with its own custom sound — either picked from your phone's storage or
recorded right in the app.

## How to open and build

1. Install **Android Studio** (Koala or newer) if you don't have it.
2. Open Android Studio → **Open** → select this `ReminderApp` folder.
3. Let Gradle sync (it will download dependencies the first time — needs
   internet access).
4. Plug in a phone (with USB debugging on) or start an emulator running
   **Android 8.0 (API 26) or higher**.
5. Click **Run ▶**.

## How it works

- **Add a reminder**: tap the `+` button, give it a title, pick a time, then
  either **Choose file** (pick any audio file from your device) or
  **Record audio** (records straight from the mic and saves it in the app's
  private storage).
- Reminders repeat **every day** at the chosen time.
- When it's time, the app plays the sound and shows a notification with a
  **Stop** button.
- Toggle the switch next to a reminder to enable/disable it without deleting
  it. Tap the trash icon to remove it.
- Reminders still fire after a phone restart (a boot receiver
  re-schedules everything).

## Permissions it asks for

- **Microphone** — only needed if you record audio in-app.
- **Notifications** — to show the "reminder playing" notification (Android 13+).
- **Audio files** — to let you pick a file from storage (Android 13+ uses
  `READ_MEDIA_AUDIO`).
- **Exact alarms** — so reminders fire at the precise minute you set, even in
  Doze mode.

## Notes / things you may want to adjust

- Currently every reminder repeats **daily**. If you want specific weekdays
  (e.g. only Mon/Wed/Fri) or one-time reminders, that logic lives in
  `AlarmScheduler.kt` and `Reminder.kt` — it's a small extension from here.
- On some devices (Samsung, Xiaomi, etc.) you may need to manually exempt the
  app from battery optimization for alarms to stay reliable long-term.
- This project was written and organized by hand for you to build in Android
  Studio — it hasn't been compiled/run in this environment, so if Gradle
  flags a small version mismatch, bump the relevant dependency version.
