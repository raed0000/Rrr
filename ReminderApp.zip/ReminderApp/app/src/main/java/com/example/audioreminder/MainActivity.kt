package com.example.audioreminder

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.app.ActivityCompat
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.audioreminder.data.Reminder
import com.example.audioreminder.ui.ReminderViewModel
import java.io.File

class MainActivity : ComponentActivity() {

    private val viewModel: ReminderViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Ask for runtime permissions we need (notifications on 13+, mic for recording).
        val permissionsNeeded = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissionsNeeded.add(Manifest.permission.POST_NOTIFICATIONS)
            permissionsNeeded.add(Manifest.permission.READ_MEDIA_AUDIO)
        }
        val notGranted = permissionsNeeded.filter {
            ActivityCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (notGranted.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, notGranted.toTypedArray(), 100)
        }

        setContent {
            MaterialTheme {
                AppNavHost(viewModel)
            }
        }
    }
}

@Composable
fun AppNavHost(viewModel: ReminderViewModel) {
    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = "list") {
        composable("list") { ReminderListScreen(viewModel, navController) }
        composable("add") { AddReminderScreen(viewModel, navController) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReminderListScreen(viewModel: ReminderViewModel, navController: NavHostController) {
    val reminders by viewModel.reminders.collectAsState()

    Scaffold(
        topBar = { TopAppBar(title = { Text("Audio Reminders") }) },
        floatingActionButton = {
            FloatingActionButton(onClick = { navController.navigate("add") }) {
                Icon(Icons.Default.Add, contentDescription = "Add reminder")
            }
        }
    ) { padding ->
        if (reminders.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Text("No reminders yet. Tap + to add one.")
            }
        } else {
            LazyColumn(Modifier.fillMaxSize().padding(padding)) {
                items(reminders, key = { it.id }) { reminder ->
                    ReminderRow(
                        reminder = reminder,
                        onToggle = { viewModel.toggleEnabled(reminder) },
                        onDelete = { viewModel.deleteReminder(reminder) }
                    )
                }
            }
        }
    }
}

@Composable
fun ReminderRow(reminder: Reminder, onToggle: () -> Unit, onDelete: () -> Unit) {
    ListItem(
        headlineContent = { Text(reminder.title) },
        supportingContent = {
            Text(String.format("%02d:%02d  •  %s", reminder.hour, reminder.minute, reminder.audioLabel))
        },
        trailingContent = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(checked = reminder.enabled, onCheckedChange = { onToggle() })
                IconButton(onClick = onDelete) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete")
                }
            }
        }
    )
    HorizontalDivider()
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddReminderScreen(viewModel: ReminderViewModel, navController: NavHostController) {
    val context = LocalContext.current

    var title by remember { mutableStateOf("") }
    var hour by remember { mutableIntStateOf(8) }
    var minute by remember { mutableIntStateOf(0) }
    var audioUri by remember { mutableStateOf<Uri?>(null) }
    var audioLabel by remember { mutableStateOf("No audio selected") }

    var isRecording by remember { mutableStateOf(false) }
    var recorder by remember { mutableStateOf<MediaRecorder?>(null) }
    var recordedFile by remember { mutableStateOf<File?>(null) }

    var ttsText by remember { mutableStateOf("") }
    var isGeneratingSpeech by remember { mutableStateOf(false) }
    val ttsHelper = remember { TextToSpeechHelper(context) }
    DisposableEffect(Unit) {
        onDispose { ttsHelper.shutdown() }
    }

    val timePickerState = rememberTimePickerState(initialHour = hour, initialMinute = minute, is24Hour = false)

    // --- Pick an existing audio file from device storage ---
    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            context.contentResolver.takePersistableUriPermission(
                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
            audioUri = uri
            audioLabel = queryFileName(context, uri) ?: "Selected file"
        }
    }

    Scaffold(topBar = { TopAppBar(title = { Text("New Reminder") }) }) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .verticalScrollWorkaround(),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("Reminder title") },
                modifier = Modifier.fillMaxWidth()
            )

            Text("Time (repeats daily)", style = MaterialTheme.typography.titleMedium)
            TimePicker(state = timePickerState)

            HorizontalDivider()
            Text("Reminder sound", style = MaterialTheme.typography.titleMedium)
            Text(audioLabel, style = MaterialTheme.typography.bodyMedium)

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(onClick = { filePicker.launch(arrayOf("audio/*")) }) {
                    Text("Choose file")
                }

                Button(onClick = {
                    if (!isRecording) {
                        val file = File(context.filesDir, "recording_${System.currentTimeMillis()}.m4a")
                        val mr = createRecorder(context, file)
                        mr.start()
                        recorder = mr
                        recordedFile = file
                        isRecording = true
                    } else {
                        recorder?.apply { stop(); release() }
                        recorder = null
                        isRecording = false
                        recordedFile?.let {
                            audioUri = Uri.fromFile(it)
                            audioLabel = "Recording (${it.name})"
                        }
                    }
                }) {
                    Text(if (isRecording) "Stop recording" else "Record audio")
                }
            }

            HorizontalDivider()
            Text("Or type text to speak", style = MaterialTheme.typography.titleMedium)

            OutlinedTextField(
                value = ttsText,
                onValueChange = { ttsText = it },
                label = { Text("Text for the reminder to say") },
                modifier = Modifier.fillMaxWidth()
            )

            Button(
                onClick = {
                    isGeneratingSpeech = true
                    ttsHelper.synthesizeToFile(ttsText) { file ->
                        isGeneratingSpeech = false
                        if (file != null) {
                            audioUri = Uri.fromFile(file)
                            audioLabel = "Spoken: \"$ttsText\""
                        } else {
                            audioLabel = "Couldn't generate speech, try again"
                        }
                    }
                },
                enabled = ttsText.isNotBlank() && !isGeneratingSpeech
            ) {
                Text(if (isGeneratingSpeech) "Generating..." else "Generate audio")
            }

            Spacer(Modifier.weight(1f))

            Button(
                onClick = {
                    val uri = audioUri
                    if (title.isNotBlank() && uri != null) {
                        viewModel.addReminder(
                            title = title,
                            hour = timePickerState.hour,
                            minute = timePickerState.minute,
                            audioUri = uri.toString(),
                            audioLabel = audioLabel
                        )
                        navController.popBackStack()
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                enabled = title.isNotBlank() && audioUri != null
            ) {
                Text("Save reminder")
            }
        }
    }
}

private fun createRecorder(context: android.content.Context, outFile: File): MediaRecorder {
    val recorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        MediaRecorder(context)
    } else {
        @Suppress("DEPRECATION")
        MediaRecorder()
    }
    recorder.setAudioSource(MediaRecorder.AudioSource.MIC)
    recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
    recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
    recorder.setOutputFile(outFile.absolutePath)
    recorder.prepare()
    return recorder
}

private fun queryFileName(context: android.content.Context, uri: Uri): String? {
    var name: String? = null
    context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
        val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
        if (cursor.moveToFirst() && nameIndex >= 0) {
            name = cursor.getString(nameIndex)
        }
    }
    return name
}

// Small helper so the Column scrolls on short screens; keeps this file dependency-free.
@Composable
private fun Modifier.verticalScrollWorkaround(): Modifier {
    val scrollState = androidx.compose.foundation.rememberScrollState()
    return this.then(androidx.compose.foundation.verticalScroll(scrollState))
}
