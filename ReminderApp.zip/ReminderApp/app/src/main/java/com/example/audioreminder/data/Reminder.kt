package com.example.audioreminder.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * One reminder. Repeats every day at [hour]:[minute].
 * [audioUriString] points to either:
 *   - a content:// Uri the user picked from storage, or
 *   - a file:// path under the app's private files dir for an in-app recording.
 */
@Entity(tableName = "reminders")
data class Reminder(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val hour: Int,           // 0-23
    val minute: Int,         // 0-59
    val audioUriString: String,
    val audioLabel: String,  // friendly name shown in the UI (file name or "Recording")
    val enabled: Boolean = true
)
