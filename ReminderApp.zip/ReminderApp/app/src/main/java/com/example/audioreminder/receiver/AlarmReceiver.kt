package com.example.audioreminder.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import com.example.audioreminder.data.AlarmScheduler
import com.example.audioreminder.data.AppDatabase
import com.example.audioreminder.service.ReminderPlaybackService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class AlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val reminderId = intent.getIntExtra("reminder_id", -1)
        val title = intent.getStringExtra("title") ?: "Reminder"
        val audioUri = intent.getStringExtra("audio_uri") ?: return

        // 1. Start the foreground service to actually play the audio + show a notification.
        val serviceIntent = Intent(context, ReminderPlaybackService::class.java).apply {
            putExtra("title", title)
            putExtra("audio_uri", audioUri)
        }
        ContextCompat.startForegroundService(context, serviceIntent)

        // 2. Re-schedule this same reminder for tomorrow (daily repeat).
        if (reminderId != -1) {
            val pendingResult = goAsync()
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val dao = AppDatabase.getInstance(context).reminderDao()
                    val reminder = dao.getById(reminderId)
                    if (reminder != null && reminder.enabled) {
                        AlarmScheduler.schedule(context, reminder)
                    }
                } finally {
                    pendingResult.finish()
                }
            }
        }
    }
}
