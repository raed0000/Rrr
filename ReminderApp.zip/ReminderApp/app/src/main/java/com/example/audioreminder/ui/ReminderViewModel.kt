package com.example.audioreminder.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audioreminder.data.AlarmScheduler
import com.example.audioreminder.data.AppDatabase
import com.example.audioreminder.data.Reminder
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ReminderViewModel(app: Application) : AndroidViewModel(app) {

    private val dao = AppDatabase.getInstance(app).reminderDao()

    val reminders: StateFlow<List<Reminder>> = dao.getAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun addReminder(title: String, hour: Int, minute: Int, audioUri: String, audioLabel: String) {
        viewModelScope.launch {
            val reminder = Reminder(
                title = title,
                hour = hour,
                minute = minute,
                audioUriString = audioUri,
                audioLabel = audioLabel,
                enabled = true
            )
            val newId = dao.insert(reminder)
            AlarmScheduler.schedule(getApplication(), reminder.copy(id = newId.toInt()))
        }
    }

    fun toggleEnabled(reminder: Reminder) {
        viewModelScope.launch {
            val updated = reminder.copy(enabled = !reminder.enabled)
            dao.update(updated)
            if (updated.enabled) {
                AlarmScheduler.schedule(getApplication(), updated)
            } else {
                AlarmScheduler.cancel(getApplication(), updated)
            }
        }
    }

    fun deleteReminder(reminder: Reminder) {
        viewModelScope.launch {
            AlarmScheduler.cancel(getApplication(), reminder)
            dao.delete(reminder)
        }
    }
}
