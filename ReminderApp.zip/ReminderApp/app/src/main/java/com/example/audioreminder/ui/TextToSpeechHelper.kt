package com.example.audioreminder.ui

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.io.File
import java.util.Locale
import java.util.UUID

/**
 * Wraps Android's built-in TextToSpeech engine so we can turn typed text into
 * a small audio file that gets used as a reminder sound, same as a picked or
 * recorded file.
 */
class TextToSpeechHelper(context: Context) {

    private var tts: TextToSpeech? = null
    private var ready = false
    private val appContext = context.applicationContext

    init {
        tts = TextToSpeech(appContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.getDefault()
                ready = true
            }
        }
    }

    /**
     * Synthesizes [text] to a .wav file in the app's private storage and calls
     * [onResult] with the resulting File, or null if synthesis failed.
     */
    fun synthesizeToFile(text: String, onResult: (File?) -> Unit) {
        val engine = tts
        if (engine == null || text.isBlank()) {
            onResult(null)
            return
        }

        val file = File(appContext.filesDir, "tts_${UUID.randomUUID()}.wav")
        val utteranceId = UUID.randomUUID().toString()

        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) {
                if (id == utteranceId) onResult(file)
            }
            @Deprecated("Deprecated in Java")
            override fun onError(id: String?) {
                if (id == utteranceId) onResult(null)
            }
            override fun onError(id: String?, errorCode: Int) {
                if (id == utteranceId) onResult(null)
            }
        })

        val result = engine.synthesizeToFile(text, null, file, utteranceId)
        if (result != TextToSpeech.SUCCESS) {
            onResult(null)
        }
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}
